#!/bin/bash
tar -xvzf start_to_ec2.tar.gz 
bash start_app.sh
