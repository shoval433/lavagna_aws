#!/bin/bash

if [ $1 ];then
var=$1
fi

docker build -t my_img:${var} .

aws ecr-public get-login-password --region us-east-1 | docker login --username AWS --password-stdin public.ecr.aws/c7o8u9c1

docker tag my_img:${var} public.ecr.aws/c7o8u9c1/shoval_ecr:latest

docker push public.ecr.aws/c7o8u9c1/shoval_ecr:latest

tar -czvf start_to_ec2.tar.gz docker-compose.yaml start_app.sh ./src/main/webapp ./nginx1

echo "yes" | scp start_to_ec2.tar.gz ubuntu@13.37.227.82:/home/ubuntu/

ssh ubuntu@13.37.227.82 "bash ec2_script.sh"
