#!/bin/bash

docker compose up -d

docker rmi -f $(docker images -q)


